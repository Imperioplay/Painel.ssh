# SSHPLUS

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/Imperioplay/SSHVIP/main/Plus && chmod 777 Plus && ./Plus


#Acessa Root

wget https://raw.githubusercontent.com/Imperioplay/SSHVIP/main/senharoot.sh && chmod 777 senharoot.sh && ./senharoot.sh
