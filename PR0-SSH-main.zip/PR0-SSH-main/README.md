# IMPERIO SSH PLUS ⚡

# @ARROWCLOUD_25

*PROJETO EM BETA🍷🗿
```
apt install wget -y; bash <(wget -qO- raw.githubusercontent.com/Imperioplay/Painel.ssh/main/ssh-plus)

```
